package it.uniroma3.siw.nw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
