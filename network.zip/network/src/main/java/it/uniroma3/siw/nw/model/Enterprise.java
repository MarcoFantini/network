package it.uniroma3.siw.nw.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table (name = "enterprise")
public class Enterprise extends User {
	
	private String vatin;
	
	@OneToMany(mappedBy = "provider")
	private List<Quote> quotes;
	
	@OneToMany(mappedBy = "recipient", fetch = FetchType.EAGER)
	private List<Request> privateRequest;
	
	public Enterprise() {
		super();
		this.quotes = new ArrayList<>();
		this.privateRequest = new ArrayList<>();
	}

	public String getVatin() {
		return vatin;
	}

	public void setVatin(String vatin) {
		this.vatin = vatin;
	}

	public List<Quote> getQuotes() {
		return quotes;
	}

	public void setQuotes(List<Quote> quotes) {
		this.quotes = quotes;
	}

	public List<Request> getPrivateRequest() {
		return privateRequest;
	}

	public void setPrivateRequest(List<Request> privateRequest) {
		this.privateRequest = privateRequest;
	}

	public void addQuotes(Quote quote) {
		if (!this.quotes.contains(quote))
            this.quotes.add(quote);
	}

	@Override
	public int hashCode() {
		return this.getName().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		Enterprise other = (Enterprise) obj;
		return this.getName().equals(other.getName());
	}

	@Override
	public String toString() {
		return "Enterprise [vatin=" + this.vatin + super.toString();
	}
}