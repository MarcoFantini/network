package it.uniroma3.siw.nw.controller;

import java.util.List;

import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.nw.controller.session.SessionData;
import it.uniroma3.siw.nw.controller.validation.RequestValidator;
import it.uniroma3.siw.nw.model.Customer;
import it.uniroma3.siw.nw.model.Quote;
import it.uniroma3.siw.nw.model.Request;
import it.uniroma3.siw.nw.model.User;
import it.uniroma3.siw.nw.service.QuoteService;
import it.uniroma3.siw.nw.service.RequestService;

@Controller
public class RequestController {

	@Autowired
	protected RequestValidator requestValidator;

	@Autowired
	protected SessionData sessionData;

	@Autowired
	protected RequestService requestService;
	
	@Autowired
	protected QuoteService quoteService;

	@RequestMapping(value = {"/requests/add/private"}, method = RequestMethod.POST)
	public String createPrivateRequest(@Valid @ModelAttribute("requestForm") Request request, 
			BindingResult requestBindingResult, Model model) {

		User loggedUser = sessionData.getLoggedUser();
		requestValidator.validate(request, requestBindingResult);

		if(!requestBindingResult.hasErrors()) {
			request.setApplicant((Customer)loggedUser);
			/**
			 * controllo se esiste già una richiesta con lo stesso codice 
			 * questa non è una operazione costosa perchè su 10000 generazioni
			 * succede solo 5 volte */
			while (this.requestService.getRequest(request.getCode()) != null)
				request.setCode();

			this.requestService.saveRequest(request);

			return "requestSuccessful";
		}
		model.addAttribute("loggedUser", loggedUser);
		return "enterprisesWindow";
	}

	@RequestMapping(value = {"/requests/add/public"}, method = RequestMethod.POST)
	public String createPublicRequest(@ModelAttribute("requestForm") Request request, Model model) {

		User loggedUser = sessionData.getLoggedUser();
		request.setApplicant((Customer)loggedUser);
		/**
		 * controllo se esiste già una richiesta con lo stesso codice 
		 * questa non è una operazione costosa perchè su 10000 generazioni
		 * succede solo 5 volte */
		while (this.requestService.getRequest(request.getCode()) != null)
			request.setCode();
		
		this.requestService.saveRequest(request);
		model.addAttribute("loggedUser", loggedUser);
		return "requestSuccessful";
	}

	@RequestMapping(value = "/requests/{id}/setState", method = RequestMethod.POST)
	public String setStateRequest(Model model, @PathVariable Long id) {
		Request currentRequest = this.requestService.getRequest(id);
		currentRequest.setState(Request.CLOSED);
		currentRequest = this.requestService.saveRequest(currentRequest);
		return "redirect:/home";
	}

	@RequestMapping(value = "/requests/{id}/show", method = RequestMethod.GET)
	public String showListOfQuotes(Model model, @PathVariable Long id) {
		User loggedUser = sessionData.getLoggedUser();
		Request currentRequest = this.requestService.getRequest(id);
		
		List<Quote> quotesList = currentRequest.getQuotes();
		
		model.addAttribute("quotesList", quotesList);
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("currentRequest", currentRequest);
		
		return "quotesOfRequest";
	}

}
