package it.uniroma3.siw.nw.model;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;

@Entity
public class Quote {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column(nullable = false)
	private String code;

	@ManyToOne(fetch = FetchType.LAZY)
	private Enterprise provider;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private Request request;
	
	private Float price;
	
	private String description;
	
	private LocalDate date;
	
	public Quote() {
	}
	
	@PrePersist
	protected void onPersist() {
		this.date = LocalDate.now();
	}
	
	public Long getId() {
		return this.id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Enterprise getProvider() {
		return provider;
	}

	public void setProvider(Enterprise provider) {
		this.provider = provider;
	}

	public Request getRequest() {
		return request;
	}

	public void setRequest(Request request) {
		this.request = request;
	}

	public LocalDate getDate() {
		return date;
	}

	@Override
	public int hashCode() {
		return this.code.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		Quote other = (Quote) obj;
		return this.getProvider().equals(other.getProvider());
	}

	@Override
	public String toString() {
		return "Quote [code=" + code + ", description=" + description + ", date=" + date + ", provider=" + provider + "]";
	}
}