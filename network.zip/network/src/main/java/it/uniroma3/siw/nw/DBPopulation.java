
package it.uniroma3.siw.nw;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import it.uniroma3.siw.nw.model.Customer;
import it.uniroma3.siw.nw.model.Credentials;
import it.uniroma3.siw.nw.model.Enterprise;
import it.uniroma3.siw.nw.model.Quote;
import it.uniroma3.siw.nw.model.Request;
import it.uniroma3.siw.nw.repository.CredentialsRepository;
import it.uniroma3.siw.nw.repository.RequestRepository;

import java.io.IOException;

@Component
public class DBPopulation implements ApplicationRunner {

    @Autowired
    private CredentialsRepository CredentialsRepository;
    
    @Autowired
    private RequestRepository requestRepository;
    
    @Autowired
	protected PasswordEncoder passwordEncoder;

    
    public void run(ApplicationArguments args) throws Exception {
        this.populateDB();
    }

    private void populateDB() throws IOException, InterruptedException {

    	System.out.println("Storing data...");
    	
    	// costruisco un Cliente 
    	Customer customer = new Customer();
    	customer.setName("MARCO");
    	customer.setSurname("FANTINI");
    	customer.setAddress("Via dell'impruneta 132");
    	customer.setEmail("marco@email.it");
    	customer.setPhone("3661650792");
    	customer.setCity("Roma");
    	customer.setZipcode("00146");
    	
    	Customer customer1 = new Customer();
    	customer1.setName("FABIO");
    	customer1.setSurname("VIOTTI");
    	customer1.setAddress("Via Calci Nacci 45");
    	customer1.setEmail("fabio@email.it");
    	customer1.setPhone("3661650793");
    	customer1.setCity("Roma");
    	customer1.setZipcode("00144");
    	
    	Customer customer2 = new Customer();
    	customer2.setName("ANDREA");
    	customer2.setSurname("ROSSI");
    	customer2.setAddress("Via Lombi 45");
    	customer2.setEmail("andrea@email.it");
    	customer2.setPhone("3661650794");
    	customer2.setCity("Roma");
    	customer2.setZipcode("00144");

    	// costruisco le credenziali del cliente
        Credentials customerCredentials = new Credentials();
        customerCredentials.setUsername("marcofantini");
        customerCredentials.setPassword("password");
        // setto la password criptata
        customerCredentials.setPassword(this.passwordEncoder.encode(customerCredentials.getPassword()));
        //System.out.println("customerPasswordBCrypt: " + customerCredentials.getPassword());
        // setto il ruolo da Cliente
        customerCredentials.setRole(Credentials.CUSTOMER_ROLE);
        // setto il Cliente
        customerCredentials.setUser(customer);
        
        // costruisco le credenziali del cliente
        Credentials customer1Credentials = new Credentials();
        customer1Credentials.setUsername("fabioviotti");
        customer1Credentials.setPassword("password");
        // setto la password criptata
        customer1Credentials.setPassword(this.passwordEncoder.encode(customer1Credentials.getPassword()));
        //System.out.println("customerPasswordBCrypt: " + customer1Credentials.getPassword());
        // setto il ruolo da Cliente
        customer1Credentials.setRole(Credentials.CUSTOMER_ROLE);
        // setto il Cliente
        customer1Credentials.setUser(customer1);
        
        // costruisco le credenziali del cliente
        Credentials customer2Credentials = new Credentials();
        customer2Credentials.setUsername("andrearossi");
        customer2Credentials.setPassword("password");
        // setto la password criptata
        customer2Credentials.setPassword(this.passwordEncoder.encode(customer2Credentials.getPassword()));
        //System.out.println("customerPasswordBCrypt: " + customer2Credentials.getPassword());
        // setto il ruolo da Cliente
        customer2Credentials.setRole(Credentials.CUSTOMER_ROLE);
        // setto il Cliente
        customer2Credentials.setUser(customer2);
        
    	// costruisco un'impresa 
        Enterprise enterprise = new Enterprise();
        enterprise.setName("RomaTre");
        enterprise.setAddress("Via Vito Volterra, 64");
        enterprise.setEmail("roma3@stud.uniroma3.it");
        enterprise.setVatin("12345678900");
        enterprise.setCity("Roma");
        enterprise.setZipcode("00146");
        enterprise.setPhone("098-984345345");
        
        Enterprise enterprise1 = new Enterprise();
        enterprise1.setName("MerialdoEnterprise");
        enterprise1.setAddress("Via Washington, 64");
        enterprise1.setEmail("info@bsl.enterprise.com");
        enterprise1.setVatin("12345678900");
        enterprise1.setCity("Roma");
        enterprise1.setZipcode("00146");
        enterprise1.setPhone("098-984345345");
        
     // costruisco le credenziali di un'impresa
        Credentials enterpriseCredentials = new Credentials();
        enterpriseCredentials.setUsername("romatre");
        enterpriseCredentials.setPassword("password");
        // setto la password criptata
        enterpriseCredentials.setPassword(this.passwordEncoder.encode(enterpriseCredentials.getPassword()));
        //System.out.println("enterprisePasswordBCypt: " + enterpriseCredentials.getPassword());
        // setto il ruolo da Impresa
        enterpriseCredentials.setRole(Credentials.ENTERPRISE_ROLE);
        // setto l'Impresa
        enterpriseCredentials.setUser(enterprise);
        
     // costruisco le credenziali di un'impresa
        Credentials enterprise1Credentials = new Credentials();
        enterprise1Credentials.setUsername("paolomerialdo");
        enterprise1Credentials.setPassword("password");
        // setto la password criptata
        enterprise1Credentials.setPassword(this.passwordEncoder.encode(enterprise1Credentials.getPassword()));
        //System.out.println("enterprisePasswordBCypt: " + enterpriseCredentials.getPassword());
        // setto il ruolo da Impresa
        enterprise1Credentials.setRole(Credentials.ENTERPRISE_ROLE);
        // setto l'Impresa
        enterprise1Credentials.setUser(enterprise1);
        
        // carico i dati nel database sfruttando il CascadeType.ALL
        customerCredentials = this.CredentialsRepository.save(customerCredentials);
        customer1Credentials = this.CredentialsRepository.save(customer1Credentials);
        customer2Credentials = this.CredentialsRepository.save(customer2Credentials);
        enterpriseCredentials = this.CredentialsRepository.save(enterpriseCredentials);
        enterprise1Credentials = this.CredentialsRepository.save(enterprise1Credentials);
        
        Request request = new Request();
        request.setCode();
        request.setName("First Request");
        request.setDescription("description");
        request.setApplicant(customer);
        
        Request request1 = new Request();
        request1.setCode();
        request1.setName("Second Request");
        request1.setDescription("description 1");
        request1.setApplicant(customer1);
        
        Request request2 = new Request();
        request2.setCode();
        request2.setName("Third Request");
        request2.setDescription("description 2");
        request2.setApplicant(customer2);
        
        Request privateRequest = new Request();
        privateRequest.setCode();
        privateRequest.setName("Private Request");
        privateRequest.setDescription("Private Request");
        privateRequest.setApplicant(customer);
        privateRequest.setRecipient(enterprise1);
        
        Quote quote = new Quote();
        quote.setCode(request1.getCode());
        quote.setProvider(enterprise);
        quote.setDescription("Questa è una Quote");
        quote.setPrice(new Float(550));
        quote.setRequest(request1);
        enterprise.addQuotes(quote);
        request1.addQuotes(quote);
        
        // le richieste salvano anche le quote in cascade.ALL
        privateRequest = this.requestRepository.save(privateRequest);
        request = this.requestRepository.save(request);
        request1 = this.requestRepository.save(request1);
        request2 = this.requestRepository.save(request2);
                
        System.out.println("Done.");
    }
}
