package it.uniroma3.siw.nw.controller;

import javax.validation.Valid;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.nw.controller.validation.CredentialsValidator;
import it.uniroma3.siw.nw.controller.validation.CustomerValidator;
import it.uniroma3.siw.nw.controller.validation.EnterpriseValidator;
import it.uniroma3.siw.nw.model.Credentials;
import it.uniroma3.siw.nw.model.Customer;
import it.uniroma3.siw.nw.model.Enterprise;
import it.uniroma3.siw.nw.service.CredentialsService;

@Controller
public class RegistrationController {
	
	@Autowired
	private CredentialsService credentialsService;
	
	@Autowired
	private EnterpriseValidator enterpriseValidator;
	
	@Autowired
	private CustomerValidator customerValidator;
	
	@Autowired
	private CredentialsValidator credentialsValidator;
	
	@RequestMapping(value = {"/users/register/customer"}, method = RequestMethod.GET)
	public String showCustomerRegisterForm(Model model) {
		model.addAttribute("customerForm", new Customer()); //viene aggiunto al modello uno User vuoto
		model.addAttribute("credentialsForm", new Credentials()); //viene aggiunto al modello un Credentials vuoto
		return "registerCustomer";
	}
	
	@RequestMapping(value = {"/users/register/enterprise"}, method = RequestMethod.GET)
	public String showEnterpriseRegisterForm(Model model) {
		model.addAttribute("enterpriseForm", new Enterprise()); //viene aggiunto al modello uno User vuoto
		model.addAttribute("credentialsForm", new Credentials()); //viene aggiunto al modello un Credentials vuoto
		return "registerEnterprise";
	}
	
	@RequestMapping(value = {"/users/register/customer"}, method = RequestMethod.POST)
	public String registerCustomer(@Valid @ModelAttribute("customerForm") Customer customer,
			BindingResult customerBindingResult,
			@Valid @ModelAttribute("credentialsForm") Credentials credentials,
			BindingResult credentialsBindingResult,
			Model model) {
		
		this.customerValidator.validate(customer, customerBindingResult);
		this.credentialsValidator.validate(credentials, credentialsBindingResult);
		
		if(!customerBindingResult.hasErrors() && !credentialsBindingResult.hasErrors()) {
			//set the user and store the credentials;
			//this also stores the Customer, thanks to Cascade.ALL policy
			customer.setName(customer.getName().toUpperCase());
			customer.setSurname(customer.getSurname().toUpperCase());
			credentials.setUser(customer);
			credentialsService.saveCredentials(credentials);
			return "registrationSuccessful";
		}
		return "registerCustomer";
	}
	
	@RequestMapping(value = {"/users/register/enterprise"}, method = RequestMethod.POST)
	public String registerEnterprise(@Valid @ModelAttribute("enterpriseForm") Enterprise enterprise,
			BindingResult enterpriseBindingResult,
			@Valid @ModelAttribute("credentialsForm") Credentials credentials,
			BindingResult credentialsBindingResult,
			Model model) {
		
		this.enterpriseValidator.validate(enterprise, enterpriseBindingResult);
		this.credentialsValidator.validate(credentials, credentialsBindingResult);
		
		if(!enterpriseBindingResult.hasErrors() && !credentialsBindingResult.hasErrors()) {
			//set the user and store the credentials;
			//this also stores the Customer, thanks to Cascade.ALL policy
			credentials.setUser(enterprise);
			credentialsService.saveCredentials(credentials);
			return "registrationSuccessful";
		}
		return "registerEnterprise";
	}
}
