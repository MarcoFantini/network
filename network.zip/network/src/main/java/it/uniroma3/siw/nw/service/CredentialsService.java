package it.uniroma3.siw.nw.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.nw.model.Credentials;
import it.uniroma3.siw.nw.repository.CredentialsRepository;

@Service
public class CredentialsService {
	
	@Autowired
	protected CredentialsRepository credentialsRepository;
	
	@Autowired
	protected PasswordEncoder passwordEncoder;
	
	
	@Transactional
	public Credentials getCredentials(long id) {
		Optional<Credentials> result = credentialsRepository.findById(id);
		return result.orElse(null);
	}
	
	@Transactional
	public Credentials getCredentials(String username) {
		Optional<Credentials> result = credentialsRepository.findByUsername(username);
		return result.orElse(null);
	}
	
	@Transactional
	public Credentials saveCredentials(Credentials credentials) {
		
		credentials.setRole(credentials.getUser().getClass().getSimpleName().toUpperCase());
		credentials.setPassword(this.passwordEncoder.encode(credentials.getPassword()));
		
		return this.credentialsRepository.save(credentials);
	}

	@Transactional
	public void deleteCredentials(Credentials credentials) {
		credentialsRepository.delete(credentials);
	}
	

}
