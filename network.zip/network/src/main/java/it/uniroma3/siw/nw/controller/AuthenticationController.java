package it.uniroma3.siw.nw.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.nw.controller.session.SessionData;
import it.uniroma3.siw.nw.model.Credentials;
import it.uniroma3.siw.nw.model.Customer;
import it.uniroma3.siw.nw.model.Enterprise;
import it.uniroma3.siw.nw.model.Quote;
import it.uniroma3.siw.nw.model.Request;
import it.uniroma3.siw.nw.service.QuoteService;
import it.uniroma3.siw.nw.service.RequestService;

@Controller
public class AuthenticationController {

    @Autowired
    SessionData sessionData;
    
    @Autowired
    protected RequestService requestService;
    
    @Autowired
    protected QuoteService quoteService;
    
    @RequestMapping(value = {"/login" }, method = RequestMethod.GET)
    public String showLoginPage(Model model) {
		model.addAttribute("CredentialsForm", new Credentials());
		model.addAttribute("loginError", new Boolean(false));
        return "login";
    }
    
    @RequestMapping(value = {"/failure-login" })
    public String showLoginError(Model model) {
		model.addAttribute("CredentialsForm", new Credentials());
		model.addAttribute("loginError", new Boolean(true));
        return "login";
    }
	
	@RequestMapping(value = {"/logout"}, method = RequestMethod.GET)
    public String fetchSignoutSite(HttpServletRequest request, HttpServletResponse response){
          
        HttpSession session = request.getSession(false);
        SecurityContextHolder.clearContext();

        session = request.getSession(false);
        if(session != null) {
            session.invalidate();
        }
        
        return "login";
    }
	
	@RequestMapping(value = {"/home"})
    public String defaultAfterLogin(Model model) {
		
		System.out.println(this.sessionData.getLoggedCredentials().getRole());
		
        if (this.sessionData.getLoggedCredentials().getRole().equals("ENTERPRISE")) {
        	
        	Enterprise loggedEnterprise = (Enterprise)this.sessionData.getLoggedUser();
        	
        	List<Request> privateRequest = this.requestService.getAllPrivateRequests(loggedEnterprise);
        	List<Request> publicRequest = this.requestService.getAllPublicRequests();
        	
        	List<Quote> myQuote = this.quoteService.retrieveQuotesProvidedBy(loggedEnterprise);

    		model.addAttribute("loggedUser", loggedEnterprise);
    		
    		model.addAttribute("privateRequestList", privateRequest);
    		model.addAttribute("publicRequestList", publicRequest);
    		
    		model.addAttribute("myQuoteList", myQuote);    	
    		
    		model.addAttribute("quoteForm", new Quote());
        	
            return "enterprise";
            
        } else {
        	
        	Customer loggedCustomer = (Customer)this.sessionData.getLoggedUser();
        	model.addAttribute("loggedUser", loggedCustomer);
        	model.addAttribute("requestForm", new Request());
        	
        	System.out.println(loggedCustomer);
    		List<Request> publicRequests = this.requestService.retrievePublicRequestOwnedBy(loggedCustomer);
    		model.addAttribute("publicRequestsList", publicRequests);
    		
    		List<Request> privateRequests = this.requestService.retrievePrivateRequestOwnedBy(loggedCustomer);
    		model.addAttribute("privateRequestsList", privateRequests);
        	
        	return "customer";
        }
        	
    }
	
	
}
