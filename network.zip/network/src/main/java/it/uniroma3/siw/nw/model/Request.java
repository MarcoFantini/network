package it.uniroma3.siw.nw.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;

import it.uniroma3.siw.nw.model.support.Code;

@Entity
public class Request {

	public final static String OPEN = "OPEN";
	public final static String CLOSED = "CLOSED";
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column(nullable = false)
	private String code;
	
	@Column(nullable = false)
	private String name;
	
	@Column(nullable = false)
	private LocalDate date;
	
	private String state;
	
	private String description;
	
	@ManyToOne
	private Customer applicant;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private Enterprise recipient;
	
	@OneToMany(mappedBy = "request", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Quote> quotes;
	
	public Request() {
		this.quotes = new ArrayList<>();
		this.state = Request.OPEN;
		this.code = new Code().generateCode(8, false);
	}
	
	@PrePersist
	protected void onPersist() {
		this.date = LocalDate.now();
	}

	public Long getId() {
		return id;
	}
	
	public Customer getApplicant() {
		return applicant;
	}

	public void setApplicant(Customer applicant) {
		this.applicant = applicant;
	}
	
	public LocalDate getDate() {
		return date;
	}

	public String getCode() {
		return code;
	}

	public void setCode() {
		this.code = new Code().generateCode(8, false);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Enterprise getRecipient() {
		return recipient;
	}

	public void setRecipient(Enterprise recipient) {
		this.recipient = recipient;
	}

	public List<Quote> getQuotes() {
		return quotes;
	}

	public void setQuotes(List<Quote> quotes) {
		this.quotes = quotes;
	}
	
	public void addQuotes(Quote quote) {
		if (!this.quotes.contains(quote))
            this.quotes.add(quote);
	}

	@Override
	public int hashCode() {
		return this.getCode().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		Request other = (Request) obj;
		return this.getCode().equals(other.getCode());
	}

	@Override
	public String toString() {
		return "Request [code=" + code + ", name=" + name + ", description=" + description + ", date=" + date + "]";
	}
}