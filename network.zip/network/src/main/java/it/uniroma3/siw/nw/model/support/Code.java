package it.uniroma3.siw.nw.model.support;

//import java.util.ArrayList;
//import java.util.List;
import java.util.Random;

public class Code {

	// array delle lettere
	private String[] Caratteri = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "L", "M", "N",
			"O", "P", "Q", "R", "S", "T", "U", "V", "Z", "Y", "J", "K", "X", "W"};

	// array dei numeri
	private String[] Numeri = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };

	// array dei caratteri speciali
	private String[] Speciali = { "!", "£", "$", "%", "&", "@", "*", ",", "_", "-", "#", ";", "^", "/", ":", ".", "+",
			"§", "?", "ç" };

	// creo l'oggetto random
	private Random rand = new Random();

	public String generateCode(int numeroCaratteriRandom, boolean conSpeciali) {

		// ottengo la lunghezza di ogni array
		int lunghezzaCaratteri = Caratteri.length;
		int lunghezzaNumeri = Numeri.length;
		int lunghezzaSpeciali = Speciali.length;

		// istanzio la variabile che conterrà il prodotto finale
		String stringaRandom = "";

		while (stringaRandom.length() < numeroCaratteriRandom) {

			// ottengo un elemento casuale per ogni array
			int c = rand.nextInt(lunghezzaCaratteri);
			int n = rand.nextInt(lunghezzaNumeri);
			int s = rand.nextInt(lunghezzaSpeciali);

			// aggiungo una lettera casuale
			stringaRandom += Caratteri[c];
			// aggiungo un numero random
			stringaRandom += Numeri[n];
			// se l'opzione conSpeciali è true aggiungo un carattere speciale
			if (conSpeciali) {
				stringaRandom += Speciali[s];
			}
		}

		// se la stringa generata dovesse superare il numero di caratteri
		// richiesto, la taglio.
		if (stringaRandom.length() > numeroCaratteriRandom) {
			stringaRandom = stringaRandom.substring(0, numeroCaratteriRandom);
		}

		// restituisco la stringa generata
		return stringaRandom;
	}

	
//	public static void main(String[] args) {
//	  
//	  // creo un oggetto GeneraCodiceRandom e lo chiamo codice 
//	  Code codice = new Code();
//	  
//	  int totDuplicate = 0;
//	  
//	  List<String> generato = new ArrayList<>();
//	  
//	  // creo 10 stringhe random come esempio 
//	  
//	  for (int i = 1; i <= 10000; i++) {
//		  String code = codice.generateCode(8, false);
//		  if(generato.contains(code)) { 
//			  totDuplicate++; 
//		  }
//		  generato.add(code);
//	  }
//	  
//	   // output della stringa appena creata.
//	  	 
//	  System.out.println("codici duplicati: " + totDuplicate); 
//	 
//	}
	 
}