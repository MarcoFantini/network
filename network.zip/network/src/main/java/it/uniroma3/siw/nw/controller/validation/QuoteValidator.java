package it.uniroma3.siw.nw.controller.validation;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.nw.model.Quote;

@Component
public class QuoteValidator implements Validator {
	
	final Integer MAX_DESCRIPTION_LENGTH = 1000;
		
	@Override
	public void validate(Object o, Errors errors) {
		Quote request = (Quote) o;
		String code = request.getCode().trim();
		String description = request.getDescription().trim();
		
		if (description.length() > MAX_DESCRIPTION_LENGTH)
			errors.rejectValue("description", "size");
		else if(code.isEmpty())
			errors.rejectValue("code", "required");
	}
	
	@Override
	public boolean supports(Class<?> clazz) {
		return Quote.class.equals(clazz);
	}

}
