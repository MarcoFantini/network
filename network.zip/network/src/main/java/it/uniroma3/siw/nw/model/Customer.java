package it.uniroma3.siw.nw.model;

import java.util.ArrayList;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table (name = "customer")
public class Customer extends User {
	
	@Column(nullable = false)
	private String surname;
	
	@OneToMany(mappedBy = "applicant", cascade={CascadeType.REMOVE})
	private List<Request> requests;
	
	public Customer() {
		super();
		this.requests = new ArrayList<>();
	}
	
	public Customer(String surname) {
		super();
		this.surname = surname;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public List<Request> getRequests() {
		return requests;
	}

	public void setRequests(List<Request> requests) {
		this.requests = requests;
	}

	public void addRequest(Request request) {
		if (!this.requests.contains(request))
            this.requests.add(request);
	}
	
	@Override
	public int hashCode() {
		return super.getEmail().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		Customer other = (Customer) obj;
		return super.getEmail().equals(other.getName());
	}

	@Override
	public String toString() {
		return "Customer [surname=" + this.surname + super.toString();
	}
}