package it.uniroma3.siw.nw.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.nw.controller.session.SessionData;
import it.uniroma3.siw.nw.model.Customer;
import it.uniroma3.siw.nw.model.Enterprise;
import it.uniroma3.siw.nw.model.Request;
import it.uniroma3.siw.nw.service.EnterpriseService;

@Controller
public class EnterpriseController {
	
	@Autowired
	private SessionData sessionData;
	
	@Autowired
	protected EnterpriseService enterpriseService;
	
	@RequestMapping(value = {"/enterprises"}, method = RequestMethod.GET )
	public String showEnterpriseShopWindow(Model model) {
		
		Customer loggedCustomer = (Customer)this.sessionData.getLoggedUser();
		List<Enterprise> enterpriseList = this.enterpriseService.retrieveAll();
		
		model.addAttribute("loggedUser", loggedCustomer);
		model.addAttribute("enterpriseList", enterpriseList);
		model.addAttribute("requestForm", new Request());
		
		return "enterprisesWindow";
	}

}
