package it.uniroma3.siw.nw.service;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.uniroma3.siw.nw.model.Customer;
import it.uniroma3.siw.nw.model.Enterprise;
import it.uniroma3.siw.nw.model.Request;
import it.uniroma3.siw.nw.repository.RequestRepository;


@Service
public class RequestService {

	@Autowired
	protected RequestRepository requestRepository;

	/**
	 * This method retrieves a Request from the DB based on its ID.
	 * @param id the id of the Request to retrieve from the DB
	 * @return the retrieved Request, or null if no Request with the passed ID could be found in the DB
	 */
	@Transactional
	public Request getRequest(Long id) {
		Optional<Request> result = this.requestRepository.findById(id);
		return result.orElse(null);
	}

	@Transactional
	public Request getRequest(String code) {
		Optional<Request> result = this.requestRepository.findByCode(code);
		return result.orElse(null);
	} 
	
	/**
	 * This method deletes a Request from the DB.
	 * @param request the Request to delete from DB
	 */
	@Transactional
	public void deleteRequest(Request request) {
		this.requestRepository.delete(request);
	}
	
	@Transactional
	public void deleteRequest(Long id) {
		this.requestRepository.deleteById(id);
	}
	
	/**
	 * This method saves a Request in the DB.
	 * @param request the Request to save into the DB
	 * @return the saved Request
	 */
	@Transactional
	public Request saveRequest(Request request) { 
		return this.requestRepository.save(request);

	}
	
	/**
	 * This method retrieves a List of all the publicRequest saved on the DB based on the Costumer who has sent it.
	 * @param loggedCostumer the costumer who sent those requests 
	 * @return the retrieved List of Request sent by the loggedCustomer, or an empty List if no Request could be found in the DB
	 */
	@Transactional
	public List<Request> retrievePublicRequestOwnedBy(Customer loggedCustomer) {
		List<Request> result = this.requestRepository.findPublicRequestOwnedBy(loggedCustomer.getId());
		return result;
	}

	/**
	 * This method retrieves a List of all the privateRequest saved on the DB based on the Costumer who has sent it.
	 * @param loggedCostumer the costumer who sent those requests 
	 * @return the retrieved List of Request sent by the loggedCustomer, or an empty List if no Request could be found in the DB
	 */
	@Transactional
	public List<Request> retrievePrivateRequestOwnedBy(Customer loggedCustomer) {
		List<Request> result = this.requestRepository.findPrivateRequestOwnedBy(loggedCustomer.getId());
		return result;
	}
	
	/**
	 *  Se sono una Enterprise voglio vedere tutte le richieste pubbliche alle quali ancora non ho fatto 
	 *  un preventivo.
	 *  */
	@Transactional 
	public List<Request> getAllPublicRequestsWithNoQuotesProvidedBy(Enterprise enterprise) { 
		List<Request> AllPublicRequests = this.getAllPublicRequests();
		List<Request> AllPublicRequestsWhitQuoteProvidedByLoggedEnterprise = this.requestRepository.retriveAllCodesForRequestWithQuoteProvidedBy(enterprise);
		
		List<Request> result = new ArrayList<>();
		
		for (Request i : AllPublicRequests)
			if(!AllPublicRequestsWhitQuoteProvidedByLoggedEnterprise.contains(i))
				result.add(i);

		return result; 
	}
	
	/**
	 *  Se sono una Enterprise voglio vedere tutte le richieste pubbliche al dila di chi è il proprietario 
	 *  
	 *  */
	@Transactional
	public List<Request> getAllPublicRequests() {
		Iterable<Request> iterable = this.requestRepository.findByRecipient(null);
		List<Request> result = new ArrayList<>();

		for (Request i : iterable) 
			result.add(i);

		return result;
	}
	
	/**************************************************************************************************************
	 * **************************************** METDOI UTILI ???? *************************************************
	 * ************************************************************************************************************/


	@Transactional
	public List<Request> getAllPrivateRequests(Enterprise recipient) {
		Iterable<Request> iterable = this.requestRepository.findByRecipient(recipient);
		List<Request> result = new ArrayList<>();

		for (Request i : iterable) 
			result.add(i);

		return result;
	} 

	@Transactional
	public List<Request> retrieveRequestDirectedTo(Enterprise loggedEnterprise) {
		Iterable<Request> iterable = this.requestRepository.findByRecipient(loggedEnterprise);
		List<Request> result = new ArrayList<>();

		for (Request i : iterable) 
			result.add(i);

		return result;
	} 

	@Transactional
	public List<Request> retrieveRequestOwnedBy(Customer loggedCustomer) {
		Iterable<Request> iterable = this.requestRepository.findByApplicant(loggedCustomer);
		List<Request> result = new ArrayList<>();

		for (Request i : iterable) 
			result.add(i);

		return result;
	}


}