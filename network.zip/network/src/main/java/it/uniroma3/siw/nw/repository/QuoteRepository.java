package it.uniroma3.siw.nw.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import it.uniroma3.siw.nw.model.Enterprise;
import it.uniroma3.siw.nw.model.Quote;

@Repository
public interface QuoteRepository extends CrudRepository <Quote, Long> {

	Optional<Quote> findByCode(String code);

	Iterable<Quote> findByProvider(Enterprise loggedEnterprise);

}
