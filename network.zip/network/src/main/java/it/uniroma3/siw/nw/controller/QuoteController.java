package it.uniroma3.siw.nw.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.nw.controller.session.SessionData;
import it.uniroma3.siw.nw.model.Enterprise;
import it.uniroma3.siw.nw.model.Quote;
import it.uniroma3.siw.nw.model.Request;
import it.uniroma3.siw.nw.model.User;
import it.uniroma3.siw.nw.service.QuoteService;
import it.uniroma3.siw.nw.service.RequestService;

@Controller
public class QuoteController {
		
	@Autowired
	private SessionData sessionData;

	@Autowired
	private QuoteService quoteService;
	
	@Autowired
	private RequestService requestService;
	
	@RequestMapping(value = {"/quotes/add"}, method = RequestMethod.GET)
	public String showAllPublicRequestsWithNoQuotesProvidedBy(Model model) {
		
		Enterprise loggedUser = (Enterprise)sessionData.getLoggedUser();
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("quoteForm", new Quote());
		
		List<Request> publicRequest = this.requestService.getAllPublicRequestsWithNoQuotesProvidedBy(loggedUser);
		
		model.addAttribute("publicRequestList", publicRequest);
		
		return "addQuote";
	}
	
	@RequestMapping(value = {"/quotes/add"}, method = RequestMethod.POST)
	public String addQuoteToRequest(@ModelAttribute("quoteForm") Quote quote, Model model) {
		
		User loggedUser = sessionData.getLoggedUser();
		
		quote.setProvider((Enterprise)loggedUser);
			
		Request currentRequest = this.requestService.getRequest(quote.getCode());
		quote.setRequest(currentRequest);
			
		currentRequest = this.quoteService.addQuotesToRequest(quote, currentRequest);
		
		model.addAttribute("loggedUser", loggedUser);
		
		return "quoteSuccessful";
	}
	
	@RequestMapping(value = {"/quotes/{id}/edit"}, method = RequestMethod.GET)
	public String showQuoteWillEdit(@PathVariable Long id, Model model) {
		
		Enterprise loggedUser = (Enterprise)this.sessionData.getLoggedUser();
		
		Quote currentQuote = this.quoteService.getQuote(id);
		model.addAttribute("quoteForm", currentQuote);
		
		model.addAttribute("loggedUser", loggedUser);
		return "editQuote";
	}
	
	@RequestMapping(value = {"/quotes/edit"}, method = RequestMethod.POST)
	public String editQuote(@ModelAttribute("quoteForm") Quote quote, Model model) {
		Quote editQuote = this.quoteService.getQuote(quote.getCode());
		editQuote.setDescription(quote.getDescription());
		editQuote.setPrice(quote.getPrice());
		
		this.quoteService.saveQuote(editQuote);
		
		return "redirect:/home";
	}

}
