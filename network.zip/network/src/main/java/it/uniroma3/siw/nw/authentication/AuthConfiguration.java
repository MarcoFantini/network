package it.uniroma3.siw.nw.authentication;

import org.springframework.context.annotation.Bean;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;

import static it.uniroma3.siw.nw.model.Credentials.*;

import javax.sql.DataSource;

@Configuration
@EnableWebSecurity
public class AuthConfiguration extends WebSecurityConfigurerAdapter {
	
	@Autowired
	DataSource datasource;
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
		    // authorization paragraph: here we define WHO can access WHICH pages
        	.authorizeRequests()
        	// admin all permit
            // anyone (authenticated or not) can access the welcome page, the login page, and the registration page
        	.antMatchers(HttpMethod.GET, "/", 
        			"/index", 
        			"/users/register/**",
        			"/assets/**",
        			"/css/**", "/login").permitAll()
        	
            // anyone (authenticated or not) can send POST requests to the login endpoint and the register endpoint
         	.antMatchers(HttpMethod.POST, "/login", 
         			"/users/register/**").permitAll()
         	
         	.antMatchers(HttpMethod.GET, "/enterprise",
         			"/quotes/add").hasAnyAuthority(ENTERPRISE_ROLE)
         	
         	.antMatchers(HttpMethod.GET, "/customer",
         			"/requests/add", "/enterprises").hasAnyAuthority(CUSTOMER_ROLE)
            // all authenticated users can access all the remaining other pages
        	.anyRequest().authenticated()

        	.and().formLogin()
        		.loginPage("/login")
        		.failureForwardUrl("/failure-login")
        		
        	.defaultSuccessUrl("/home")
        	.and().logout()
        	.logoutUrl("/logout")               // logout is performed when sending a GET to "/logout"
        	
        	.invalidateHttpSession(true)
			.clearAuthentication(true).permitAll();
	}
	
	@Override
    public void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.jdbcAuthentication().dataSource(this.datasource)
        	.authoritiesByUsernameQuery("SELECT username, role FROM credentials WHERE username=?")
            .usersByUsernameQuery("SELECT username, password, 1 as enabled FROM credentials WHERE username=?");
	}
	
	@Bean
	PasswordEncoder passwordEncoder() { return new BCryptPasswordEncoder(); }

}