package it.uniroma3.siw.nw.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.nw.service.RequestService;

@Controller
public class CustomerController {
	
	@Autowired
	private RequestService requestService;
	
	@RequestMapping(value = "/customer/requests/{id}/delete", method = RequestMethod.POST)
    public String removeRequest (Model model, @PathVariable Long id) {
        this.requestService.deleteRequest(id);
        return "redirect:/home";
	}

}
