package it.uniroma3.siw.nw.controller.validation;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.nw.model.Customer;

@Component
public class CustomerValidator implements Validator {
	
	final Integer MAX_NAME_LENGTH = 100;
	final Integer MIN_NAME_LENGTH = 2;
	final Integer PHONE_LENGTH = 10;
	final Integer MIN_EMAIL_LENGTH = 6;
	
	@Override
	public void validate(Object o, Errors errors) {
		Customer customer = (Customer) o;
		String name = customer.getName().trim();
		String surname = customer.getSurname().trim();
		String email = customer.getEmail().trim();
		String address = customer.getAddress().trim();
		String phone = customer.getPhone().trim();
		String city = customer.getCity().trim();
		String zipcode = customer.getZipcode().trim();
		
		if(name.isEmpty())
			errors.rejectValue("name", "required");
		else if (name.length() < MIN_NAME_LENGTH || name.length() > MAX_NAME_LENGTH)
			errors.rejectValue("name", "size");
		
		if(surname.isEmpty())
			errors.rejectValue("surname", "required");
		else if (surname.length() < MIN_NAME_LENGTH || surname.length() > MAX_NAME_LENGTH)
			errors.rejectValue("surname", "size");
		
		if(email.isEmpty())
			errors.rejectValue("email", "required");
		else if (!email.contains("@"))
			errors.rejectValue("email", "format");
		else if (!email.contains("."))
			errors.rejectValue("email", "format");
		else if (email.length() < MIN_EMAIL_LENGTH || email.length() > MAX_NAME_LENGTH)
			errors.rejectValue("email", "format");
		
		if(address.isEmpty())
			errors.rejectValue("address", "required");
		
		if(phone.isEmpty())
			errors.rejectValue("phone", "required");
		else if (phone.length() != PHONE_LENGTH)
			errors.rejectValue("phone", "format");
		
		if(city.isEmpty())
			errors.rejectValue("city", "required");
		
		if(zipcode.isEmpty())
			errors.rejectValue("zipcode", "required");
		
	}

	@Override
	public boolean supports(Class<?> clazz) {
		return Customer.class.equals(clazz);
	}
}