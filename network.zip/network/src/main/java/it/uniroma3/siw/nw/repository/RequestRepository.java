package it.uniroma3.siw.nw.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import it.uniroma3.siw.nw.model.Customer;
import it.uniroma3.siw.nw.model.Enterprise;
import it.uniroma3.siw.nw.model.Request;

@Repository
public interface RequestRepository extends CrudRepository <Request, Long> {
	
	public List<Request> findByRecipient(Enterprise enterprise);
	
	public List<Request> findByApplicant(Customer customer);

	public Optional<Request> findByCode(String code);

	@Query("SELECT r FROM Request r WHERE recipient_id IS null AND applicant_id = ?1")
    public List<Request> findPublicRequestOwnedBy(Long customer_id);

    @Query("SELECT r FROM Request r WHERE recipient_id IS NOT null AND applicant_id = ?1")
    public List<Request> findPrivateRequestOwnedBy(Long customer_id);
    
    @Query("SELECT r FROM Request r JOIN Quote q ON r.code = q.code WHERE q.provider = ?1") 
    public List<Request> retriveAllCodesForRequestWithQuoteProvidedBy(Enterprise enterprise);

	
}
