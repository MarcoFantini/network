package it.uniroma3.siw.nw.controller.validation;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.nw.model.Request;

@Component
public class RequestValidator implements Validator {
	
	final Integer MAX_DESCRIPTION_LENGTH = 500;
	
	@Override
	public void validate(Object o, Errors errors) {
		Request request = (Request) o;
		String name = request.getName().trim();
		String description = request.getDescription().trim();
		
		if(name.isEmpty())
			errors.rejectValue("name", "required");
		else if (description.length() > MAX_DESCRIPTION_LENGTH)
			errors.rejectValue("description", "size");
		
	}

	@Override
	public boolean supports(Class<?> clazz) {
		return Request.class.equals(clazz);
	}

}
